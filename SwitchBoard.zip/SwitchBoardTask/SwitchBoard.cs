﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static System.Reflection.Metadata.BlobBuilder;

namespace SwitchBoardTask
{
    public class SwitchBoard
    {
        public List<IDevice> devices = new List<IDevice>();
        public void createSwitchBoard()
        {
            int noOfFans = InputValidation.readNoOfDevices("Enter number of Fans");
            int noOfACs = InputValidation.readNoOfDevices("Enter number of AirConditioners");
            int noOfBulbs = InputValidation.readNoOfDevices("Enter number of Bulbs");
            for (int i = 1; i <= noOfFans; i++)
            {
                addFan(i);
            }
            for (int i = 1; i <= noOfACs; i++)
            {
                addAC(i);
            }
            for (int i = 1; i <= noOfBulbs; i++)
            {
                addBulb(i);
            }
        }
        public void addFan(int id)
        {
            var fan = new Fan(id, Status.OFF,"Fan");
            devices.Add(fan);
        }
        public void addAC(int id)
        {
            var ac = new AC(id, Status.OFF, "AC");
            devices.Add(ac);
        }
        public void addBulb(int id)
        {
            var bulbs = new Bulb(id, Status.OFF, "Bulb");
            devices.Add(bulbs);
        }
        public void showAllDevicesStatus()
        {
            for(int i=0;i<devices.Count;i++)
            {
                Console.WriteLine("{0}.   {1}{2} is {3} ", i + 1, devices[i].name, devices[i].id, (int)devices[i].getStatus()==1?"ON":"OFF");
            }
            Console.WriteLine("Enter 0 for Exit");
        }
    }
}


