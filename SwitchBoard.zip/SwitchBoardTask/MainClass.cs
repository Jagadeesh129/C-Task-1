﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchBoardTask
{
    public class MainClass
    {
        public static void Main()
        {
            SwitchBoard switches = new SwitchBoard();
            switches.createSwitchBoard();
            switches.showAllDevicesStatus();
            bool enter = true;
            while (enter)
            {
                int devicenumber = InputValidation.readNoOfDevices("Select the device by entering the device number");
                if (devicenumber == 0)
                    break;
                if (devicenumber > switches.devices.Count)
                {
                    Console.WriteLine("Please select the device between range as shown");
                    continue;
                }
                var device = switches.devices.ElementAt(devicenumber - 1);
                bool flag;
                do
                {
                    Console.WriteLine("1.Switch {0} {1} {2}\n2.Back\nEnter 0 for exit", device.name, device.id, (int)device.getStatus() == 0 ? "ON" : "OFF");
                    flag = false;
                    int select = InputValidation.readNoOfDevices("-------------------------");
                    if (select == 0)
                    {
                        enter = false;
                        break;
                    }
                    switch (select)
                    {
                        case 1:
                            device.setStatus();
                            flag = true;
                            break;
                        case 2:
                            switches.showAllDevicesStatus();
                            break;
                    }
                }
                while (flag);
            }
        }
    }
}
