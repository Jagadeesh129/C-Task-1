﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchBoardTask
{
    public class Bulb : IDevice
    {
        public int id { get; set; }
        public Status isOn { get; set; }
        public string? name { get; set; }
        public Bulb(int id, Status isOn, string name)
        {
            this.id = id;
            this.isOn = isOn;
            this.name = name;
        }
        public Status setStatus()
        {
            if (isOn == Status.OFF)
                isOn = Status.ON;
            else isOn = Status.OFF;
            return isOn;
        }
        public Status getStatus()
        {
            return isOn;
        }
    }
}
