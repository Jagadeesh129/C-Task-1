﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchBoardTask
{
    public class InputValidation
    {
        public static int readNoOfDevices(String deviceName)
        {
            bool flag=true;
            int result=0;
            while (flag)
            {
                flag = false;
                try
                {
                    Console.WriteLine(deviceName);
                    result = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    flag = true;
                    Console.WriteLine("Enter a proper number");
                    continue;
                }
                if (result < 0)
                {
                    flag = true;
                    Console.WriteLine("Please Enter Positive number");
                }
            }
            
            return result;
        }
    }
}
