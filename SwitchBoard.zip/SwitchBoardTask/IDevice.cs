﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchBoardTask
{
    public enum Status
    {
        OFF,
        ON,
    }
    public interface IDevice
    {
        public int id { get; set; }
        public Status isOn { get; set; }
        public string? name { get; set; }
        public Status setStatus();
        public Status getStatus();
    }
    

    
    
}
